let navbar = document.querySelector('.one .navbar')

document.querySelector('#menu-btn').onclick = () => {
    navbar.classList.add('active');
}
document.querySelector('#nav-cl').onclick = () => {
    navbar.classList.remove('active');
};

// window.onscroll = () => {
//     navbar.classList.remove('active');
//     if (window.scrollY > 0) {
//         document.querySelector('.one').classList.add('active');

//     } else {
//         document.querySelector('.one').remove('active')
//     }

// };
// window.onload = () => {

//     if (window.scrollY > 0) {
//         document.querySelector('.one').classList.add('active');

//     } else {
//         document.querySelector('.one').remove('active')
//     }

// };
// // const menuBtn = document.querySelector("#menu-btn");
// // const navbar = document.querySelector(".navbar");

// // menuBtn.addEventListener("click", () => {
// //     navbar.classList.toggle("active");
// // });
// // 
// window.addEventListener('scroll', function() {
//     const header = document.querySelector('.one');
//     header.classList.toggle('sticky', window.scrollY > 0);
// });

// setInterval(function() {
//     const container = document.querySelector('.active');
//     container.style.backgroundColor = getRandomColor();
// }, 1000);

var swiper = new Swiper(".home-slider", {
    slidesPerView: 1,
    spaceBetween: 30,
    loop: true,
    pagination: {
        el: ".swiper-pagination",
        clickable: true,
    },
    navigation: {
        nextEl: ".swiper-button-next",
        prevEl: ".swiper-button-prev",
    },
});


document.getElementById("refresh-btn").addEventListener("click", function() {
    location.reload(); /* Reload the current page */
});